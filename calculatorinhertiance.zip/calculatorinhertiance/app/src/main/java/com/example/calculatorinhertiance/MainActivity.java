package com.example.calculatorinhertiance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;



public class MainActivity extends AppCompatActivity {

    // Références aux éléments de l'interface utilisateur
    private RadioGroup genderRadioGroup;
    private RadioButton maleRadioButton;
    private RadioButton femaleRadioButton;
    private EditText inheritanceAmountEditText;
    private EditText numDaughtersEditText;
    private EditText numSonsEditText;
    private Button calculateInheritanceButton;
    private TextView inheritanceResultLabel;
    private TextView inheritanceResultTextView;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Récupération des références aux éléments de l'interface utilisateur
        genderRadioGroup = findViewById(R.id.gender_radio_group);
        maleRadioButton = findViewById(R.id.male_radio_button);
        femaleRadioButton = findViewById(R.id.female_radio_button);
        inheritanceAmountEditText = findViewById(R.id.inheritance_amount_edit_text);
        numDaughtersEditText = findViewById(R.id.num_daughters_edit_text);
        numSonsEditText = findViewById(R.id.num_sons_edit_text);
        calculateInheritanceButton = findViewById(R.id.calculate_inheritance_btn);
        inheritanceResultLabel = findViewById(R.id.inheritance_result_label);
        inheritanceResultTextView = findViewById(R.id.inheritance_result_text_view);
        submitButton = findViewById(R.id.submit_btn);

        // Gestion du clic sur le bouton de calcul de l'héritage
        calculateInheritanceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Récupération des valeurs saisies par l'utilisateur
                boolean isMale = maleRadioButton.isChecked();
                double inheritanceAmount = Double.parseDouble(inheritanceAmountEditText.getText().toString());
                int numDaughters = Integer.parseInt(numDaughtersEditText.getText().toString());
                int numSons = Integer.parseInt(numSonsEditText.getText().toString());

                // Calcul de l'héritage conformément à la loi islamique
                double inheritance = calculateInheritance(isMale, inheritanceAmount, numDaughters, numSons);

// Mise à jour de l'interface utilisateur avec le résultat du calcul
                inheritanceResultLabel.setVisibility(View.VISIBLE);
                inheritanceResultTextView.setText(String.format("%.2f", inheritance));
                inheritanceResultTextView.setVisibility(View.VISIBLE);
            }
        });


        TextView textView = findViewById(R.id.txtviww);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open MainActivity3
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(intent);
            }
        });

// Gestion du clic sur le bouton de soumission des données
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Récupération des valeurs saisies par l'utilisateur
                boolean isMale = maleRadioButton.isChecked();
                double inheritanceAmount = Double.parseDouble(inheritanceAmountEditText.getText().toString());
                int numDaughters = Integer.parseInt(numDaughtersEditText.getText().toString());
                int numSons = Integer.parseInt(numSonsEditText.getText().toString());


                if (inheritanceAmount <= 0) {

                    Toast.makeText(MainActivity.this, "يجب أن يكون المبلغ الإجمالي للوراثة أكبر من 0", Toast.LENGTH_SHORT).show();
                } else if (numDaughters < 0 || numSons < 0) {

                    Toast.makeText(MainActivity.this, "يجب أن يكون عدد الفتيات والفتيان أكبر من أو يساوي 0", Toast.LENGTH_SHORT).show();
                } else {

                    double inheritance = calculateInheritance(isMale, inheritanceAmount, numDaughters, numSons);




                    Toast.makeText(MainActivity.this, "تم إرسال البيانات بنجاح", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Calcul de l'héritage conformément à la loi islamique
     *
     * @param isMale            Booléen indiquant si le défunt est un homme (true) ou une femme (false)
     * @param inheritanceAmount Somme totale de l'héritage
     * @param numDaughters      Nombre de filles
     * @param numSons           Nombre de garçons
     * @return Héritage calculé
     */
    private double calculateInheritance(boolean isMale, double inheritanceAmount, int numDaughters, int numSons) {
        if (isMale) {
            // Si le défunt est un homme
            if (numDaughters == 0) {
                // Si le défunt n'a pas de filles, les garçons héritent la totalité de l'héritage
                return inheritanceAmount;
            } else if (numSons == 0) {
                // Si le défunt n'a pas de garçons, les filles héritent les 2/3 de la somme totale de l'héritage
                return inheritanceAmount * 2 / 3;
            } else {
                // Si le défunt a à la fois des filles et des garçons, chaque garçon hérite le double de ce qu'hérite chaque fille
                double inheritancePerDaughter = inheritanceAmount / (numDaughters + numSons * 2);
                double inheritancePerSon = inheritancePerDaughter * 2;
                return inheritancePerSon;
            }
        } else {
            // Si le défunt est une femme
            if (numDaughters == 0) {
                // Si le défunt n'a pas de filles, les garçons héritent la totalité de l'héritage
                return inheritanceAmount;
            } else if (numSons == 0) {
                // Si le défunt n'a pas de garçons, les filles héritent les 2/3 de la somme totale de l'héritage
                return inheritanceAmount * 2 / 3;
            } else {
                // Si le défunt a à la fois des filles et des garçons, chaque fille hérite le 1/2 de la somme des garçons
                double inheritancePerson = inheritanceAmount / 2;
                double inheritancePerDaughter = inheritancePerson/2;
                return inheritancePerDaughter ;
            }
        }
    }

}