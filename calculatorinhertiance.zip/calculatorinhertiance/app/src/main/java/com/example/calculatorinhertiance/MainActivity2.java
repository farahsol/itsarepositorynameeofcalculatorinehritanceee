package com.example.calculatorinhertiance;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

public class MainActivity2 extends AppCompatActivity {



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            setContentView(R.layout.activity_main2);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

            super.onCreate(savedInstanceState);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(MainActivity2.this, MainActivity.class));
                    finish();
                }
            }, 4000);
        }
    }


